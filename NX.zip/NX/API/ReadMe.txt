create a class file and paste the following

        class Nx
        {
            // Indicates if the DLL has been injected
            [DllImport("NX.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern bool isinjected();

            // Injects the DLL
            [DllImport("NX.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int inject();

            // Executes a script with a status return
            [DllImport("NX.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern void execute([MarshalAs(UnmanagedType.LPStr)] string source, out int status);

        }


1 To attach add the following to your AttachButtonClick event
 
var status = Nx.inject(); // the Statues are how it's seen if it has injected or not, status = 11 means injected, 0 means Roblox Not opened, you could do a "if status" statment to change your "is injected" label or use the garbage isinjected


to Execute just use
Nx.execute(RichTextBox); // Replace the RTB with whatever you're using PS Monacos need a script to fetch the contents of the editor