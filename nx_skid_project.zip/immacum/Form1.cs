﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

namespace immacum
{

    public partial class Form1 : Form
    {
        class Nx
        {
            // Indicates if the DLL has been injected
            [DllImport("flint.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern bool isinjected();

            // Injects the DLL
            [DllImport("flint.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern int inject();

            // Executes a script with a status return
            [DllImport("flint.dll", CallingConvention = CallingConvention.Cdecl)]
            public static extern void execute([MarshalAs(UnmanagedType.LPStr)] string source, out int status);

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var status = Nx.inject();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int status = 0;
            Nx.execute(richTextBox1.Text, out status);
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

